import { creatCardList } from "./services/dom.service.js";

creatCardList();
